#!/bin/bash

rm -rf POSCAR_* caly.log contcar.py cp2k.py get* gpid.py gulpt.py mpi* pos* pwscf.py read* remoteparallel.py results/ rvasp.py surface_run.py v2lammps.py writekp.py step* step pwscf_* STRU_* running_* Job* STRUTMP* *_fail *_finished CONTCAR* energy.dat

rm -rf data log_dir backup *.sub lbg-*.sh *_finish
